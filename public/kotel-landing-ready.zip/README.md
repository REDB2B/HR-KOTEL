# KOTEL HR AGENCY Landing Page
Готовый скомпилированный лендинг. Работает сразу при открытии index.html в любом браузере или на GitHub Pages.
